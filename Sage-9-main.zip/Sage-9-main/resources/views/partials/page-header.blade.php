@if(!is_front_page())
<div class="page-header">
  <h1>{!! App::title() !!}</h1>
</div>
@endif
